﻿using System.Diagnostics;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.Extensions.Configuration;

var config = new ConfigurationBuilder()
    .SetBasePath(AppContext.BaseDirectory)
    .AddJsonFile("appsettings.json", optional: false)
    .AddEnvironmentVariables()
    .Build();

var baseUrl = config["Server:BaseUrl"]?.TrimEnd('/');
var deviceId = config["Server:DeviceId"];
var defaultPrinter = config["Printing:DefaultPrinter"];

if (string.IsNullOrWhiteSpace(baseUrl) || string.IsNullOrWhiteSpace(deviceId))
{
    Console.Error.WriteLine("Missing Server:BaseUrl or Server:DeviceId in appsettings.json");
    return;
}

var hubUrl = $"{baseUrl}/hubs/print";
Console.WriteLine($"Connecting to {hubUrl} as {deviceId}");

var connection = new HubConnectionBuilder()
    .WithUrl(hubUrl)
    .WithAutomaticReconnect()
    .Build();

connection.On<dynamic>("PrintLoadTicket", async payload =>
{
    string ticket = payload.ticket;
    Console.WriteLine($"Received print request for ticket: {ticket}");

    try
    {
        var pdfPath = await DownloadPdfAsync(baseUrl!, ticket);
        var ok = await PrintWithCupsAsync(pdfPath, defaultPrinter);

        try { File.Delete(pdfPath); } catch { }

        Console.WriteLine(ok ? $"Printed {ticket} OK" : $"Print failed for {ticket}");
    }
    catch (Exception ex)
    {
        Console.Error.WriteLine(ex);
    }
});

await connection.StartAsync();
await connection.InvokeAsync("Register", deviceId);

Console.WriteLine("Connected. Waiting for print commands...");
await Task.Delay(Timeout.Infinite);

static async Task<string> DownloadPdfAsync(string baseUrl, string ticket)
{
    var url = $"{baseUrl}/api/printjobs/load-ticket/{Uri.EscapeDataString(ticket)}/pdf";
    var tmp = $"/tmp/LoadTicket-{ticket}-{Guid.NewGuid():N}.pdf";

    using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(30) };
    http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/pdf"));

    using var resp = await http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead);
    resp.EnsureSuccessStatusCode();

    await using var fs = File.Create(tmp);
    await using var rs = await resp.Content.ReadAsStreamAsync();
    await rs.CopyToAsync(fs);

    // tiny sanity check
    var head = await File.ReadAllBytesAsync(tmp);
    if (head.Length < 4 || head[0] != (byte)'%' || head[1] != (byte)'P' || head[2] != (byte)'D' || head[3] != (byte)'F')
        throw new Exception("Downloaded file does not look like a PDF.");

    return tmp;
}

static async Task<bool> PrintWithCupsAsync(string pdfPath, string? printer)
{
    var args = string.IsNullOrWhiteSpace(printer)
        ? $"\"{pdfPath}\""
        : $"-d \"{printer}\" \"{pdfPath}\"";

    var psi = new ProcessStartInfo
    {
        FileName = "lp",
        Arguments = args,
        RedirectStandardOutput = true,
        RedirectStandardError = true,
        UseShellExecute = false
    };

    using var proc = Process.Start(psi);
    if (proc == null) throw new Exception("Failed to start lp.");

    var stdout = await proc.StandardOutput.ReadToEndAsync();
    var stderr = await proc.StandardError.ReadToEndAsync();
    await proc.WaitForExitAsync();

    if (!string.IsNullOrWhiteSpace(stdout)) Console.WriteLine(stdout.Trim());
    if (!string.IsNullOrWhiteSpace(stderr)) Console.Error.WriteLine(stderr.Trim());

    return proc.ExitCode == 0;
}
